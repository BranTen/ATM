package atm;

import javax.swing.JOptionPane;
/*
 * this class holds all the necessary information for the account object
 */
public class Account {

	private double balance;
	private String type;
	// constructor
	public Account(String type){
		balance = 0;
		this.type = type;
	}
	
	// increases balance with deposit
	void deposit(double deposit){
		balance = balance + deposit;
	}
	
	// counts how many withdrawels from both accounts
	static int count=0;
	
	
	//method withdraws money from account
	void withdraw(double withdrawal) throws InsufficientFunds{
		if(balance < withdrawal){
			
			throw new InsufficientFunds();// if not enough money throw exception
			
		}else{
			if (count >= 4){ // of number of total withdrawels exceeds 4 charge a fee
				
				if(withdrawal + 1.5 > balance){
					
					throw new InsufficientFunds();
					
				}else{//if not then withdraw with no fee
					
			balance = balance - withdrawal - 1.5;
			count++;
			//allow user to know that fee was taken
			JOptionPane.showMessageDialog(null, "an added withdrawel fee from your " +type+ " account is 1.50");

			}
			}else{//withdraw with no problem
				balance = balance - withdrawal;
				count++;
				JOptionPane.showMessageDialog(null, "withdrawel successful from your " +type+ " account");

			}
		}
		
		
	}
	//displays balance
	void getBalance(){
		JOptionPane.showMessageDialog(null, "your current balance for your " +type+ " account is: " + balance);

	}
	//this takes money from the current account much like withdraw does and then deposits it into the other account
	double transfer(double value) throws InsufficientFunds{
		if(balance < value){
			
			throw new InsufficientFunds();
			
		}else{
			balance = balance - value;

		}
		return value;
	}
}
