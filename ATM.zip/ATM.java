package atm;


	import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;

	public class ATM extends JFrame implements ActionListener {
		
		//create all the buttons and such
		Account c = new Account("checking");
		Account s = new Account("savings");
		JPanel panel = new JPanel();
		JButton withdraw = new JButton("withdraw");
		JButton deposit = new JButton("deposit");
		JButton transfer = new JButton("transfer to");
		JButton balance = new JButton("balance");
		ButtonGroup radio = new ButtonGroup();
		JRadioButton checking = new JRadioButton("checking");
		JRadioButton savings = new JRadioButton("savings");
		JTextField amount = new JTextField(15);
		public ATM(){
			// add all the buttons and such
			setTitle("ATM");
			setVisible(true);
			setSize(250,200);
			panel.add(withdraw);
			panel.add(deposit);
			panel.add(transfer);
			panel.add(balance);
			
			radio.add(checking);
			radio.add(savings);
			panel.add(checking);
			panel.add(savings);
			panel.add(amount);
			add(panel);
			
			
			//buttons do things here
			
			withdraw.addActionListener(new ActionListener(){
				double value;
				@Override
				public void actionPerformed(ActionEvent arg0) {
					try{
						 value = Double.parseDouble(amount.getText());
						
					}catch(NumberFormatException e){
						JOptionPane.showMessageDialog(null, "not a number");
					}
					if(value % 20 != 0){
						JOptionPane.showMessageDialog(null, "withdrawel must be increments of 20");
					}else{
					if(checking.isSelected()){
						try {
							c.withdraw(value);
						} catch (InsufficientFunds e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(savings.isSelected()){
						try {
							s.withdraw(value);
						} catch (InsufficientFunds e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					}
				}
				
			});
			deposit.addActionListener(new ActionListener(){
				double value;
				@Override
				public void actionPerformed(ActionEvent arg0) {
					try{
						 value =	Double.parseDouble(amount.getText());
						
					}catch(NumberFormatException e){
						JOptionPane.showMessageDialog(null, "not a number");
					}
					if(checking.isSelected()){
						c.deposit(value);
					}
					if(savings.isSelected()){
						s.deposit(value);
					}
				}
				
			});
			transfer.addActionListener(new ActionListener(){
				double value;
				@Override
				public void actionPerformed(ActionEvent arg0) {
					try{
						 value =	Double.parseDouble(amount.getText());
						
					}catch(NumberFormatException e){
						JOptionPane.showMessageDialog(null, "not a number");
					}
					if(checking.isSelected()){
						try {
							c.deposit(s.transfer(value));
						} catch (InsufficientFunds e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(savings.isSelected()){
						try {
							s.deposit(c.transfer(value));
						} catch (InsufficientFunds e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				
			});
			balance.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent arg0) {
					if(checking.isSelected()){
						c.getBalance();
					}
					if(savings.isSelected()){
						s.getBalance();
					}
				}
			});
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			
		}
	}
