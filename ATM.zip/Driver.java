package atm;
/*
 * Brandon Tennyson
 * ATM Gui code
 * 9/14/2018
 * this program works like an atm. there are objects 
 * that are your checking and savings acounts.
 * through the GUI you will be able to withdraw,
 * deposit, transfer, and check your current balance.
 * the program will also display certian error messages
 * such as insufficent funds, invalid entry, etc
 * 
 * 
 */
public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

ATM a = new ATM();
	}

	
}
