package atm;

import javax.swing.JOptionPane;
/*
 * this is the exception class all it does is display a message
 */
public class InsufficientFunds extends Exception {
	public InsufficientFunds(){
			JOptionPane.showMessageDialog(null, "not enough balance!");	

	}

}
